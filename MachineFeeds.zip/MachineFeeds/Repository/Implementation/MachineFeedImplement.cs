﻿using System.Text.Json;
using Entities.FeedModels;
using Entities.Pagination;
using Repository.Interfaces;
using Repository.Helper;
using System.Net.Http;

namespace Repository.Implementation
{
    public class MachineFeedImplement : IMachineFeed
	{
        public PagedResponse<IEnumerable<FeedData>> GetFeed(string machineid, PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize);

            List<FeedData> FeedDataList = new List<FeedData>();
           string repairPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Constants.repairPath);
            string sessionPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Constants.sessionPath);
            using (StreamReader r = new(repairPath))
            {

                string json = r.ReadToEnd();
                var repairSource = JsonSerializer.Deserialize<Repair>(json);


                if (repairSource != null && repairSource.Repairdata.Count > 0)
                {
                    var pagedRepirData = repairSource.Repairdata.Where(t => t.machine._id.oid == machineid);


                    foreach (var repairItem in pagedRepirData)
                    {
                        FeedDataList.Add(new FeedData { feedId = repairItem._id.oid, machineId = repairItem.machine._id.oid, Feedtype = "Repair", createddate = repairItem.repair_date.date, updateddate = repairItem.updated_at.date });
                    }
                }
            }

            using (StreamReader r = new(sessionPath))
            {

                string json = r.ReadToEnd();
                var sessionSource = JsonSerializer.Deserialize<Session>(json);


                if (sessionSource != null && sessionSource.sessionsData.Count > 0)
                {
                    var pagedSessionData = sessionSource.sessionsData.Where(t => t.machineId == machineid);


                    foreach (var sessionItem in pagedSessionData)
                    {
                        FeedDataList.Add(new FeedData { feedId = sessionItem._id, machineId = sessionItem.machineId, Feedtype = "Session", createddate = sessionItem.created_at, updateddate = sessionItem.updated_at });

                    }
                }
            }
            var sortedFeedDataList = FeedDataList.OrderByDescending(t => t.createddate);

            int totalrecords = sortedFeedDataList.Count();
            //////////////////////////////////

            int skippedRepairCount = sortedFeedDataList.Take((validFilter.PageNumber - 1) * validFilter.PageSize).Where(t => t.Feedtype == "Repair").Count();
            int skippedSessionCount = sortedFeedDataList.Take((validFilter.PageNumber - 1) * validFilter.PageSize).Where(t => t.Feedtype == "Session").Count();

            var pagedFeedData = sortedFeedDataList.Skip((validFilter.PageNumber - 1) * validFilter.PageSize).Take(validFilter.PageSize).ToList();
            var currentRepairCount = pagedFeedData.Count(t => t.Feedtype == "Repair");
            var currentSessionCount = pagedFeedData.Count(t => t.Feedtype == "Session");

            int setsessionCounter = skippedSessionCount + 1;
            int setrepairCounter = skippedRepairCount + 1;
            //Set sequence number
            for (int i = 0; i < currentSessionCount + currentRepairCount; i++)
            {

                if (pagedFeedData[i].Feedtype == "Session")
                {
                    pagedFeedData[i].sequence = setsessionCounter;

                    setsessionCounter = setsessionCounter + 1;
                }
                else
                {
                    pagedFeedData[i].sequence = setrepairCounter;
                    setrepairCounter = setrepairCounter + 1;
                }
            }

            return new PagedResponse<IEnumerable<FeedData>>(pagedFeedData, validFilter.PageNumber, validFilter.PageSize, totalrecords);
        }
    }
}


﻿using System;
using Entities.FeedModels;
using Entities.Pagination;

namespace Repository.Interfaces
{
	public interface IMachineFeed
	{
        PagedResponse<IEnumerable<FeedData>> GetFeed(string machineid, PaginationFilter filter);
	}
}

		
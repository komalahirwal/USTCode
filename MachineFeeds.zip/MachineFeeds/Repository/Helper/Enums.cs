﻿using System;
namespace Repository.Helper
{
	public enum Enums
	{
	}
}


﻿using System;
namespace Repository.Helper
{
	public static class Constants
	{
		

        public const string repairPath = "RepairData.json";
        public const string sessionPath = "SessionData.json";
    }
}


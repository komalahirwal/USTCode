﻿using Entities.Pagination;
using Microsoft.AspNetCore.Mvc;
using Repository.Interfaces;

namespace MachineTalk.Controllers;

[ApiController]
[Route("[controller]")]
public class FeedController : ControllerBase
{


    private readonly ILogger<FeedController> _logger;    private readonly IMachineFeed _machinefeed;

    public FeedController(ILogger<FeedController> logger, IMachineFeed machineFeed)
    {
        _logger = logger;        _machinefeed = machineFeed;
    }

    [HttpGet("{machineid}")]
    public async Task<IActionResult> Get(string machineid, [FromQuery] PaginationFilter filter)
    {



        return Ok(_machinefeed.GetFeed(machineid, filter));
    }
}


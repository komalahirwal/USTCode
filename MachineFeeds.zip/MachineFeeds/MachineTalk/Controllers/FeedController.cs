﻿using System.Net;
using Entities.Pagination;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Mvc;
using Repository.Interfaces;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace MachineTalk.Controllers;

[ApiController]
[Route("[controller]")]
public class FeedController : ControllerBase
{


    private readonly ILogger<FeedController> _logger;    private readonly IMachineFeed _machinefeed;

    public FeedController(ILogger<FeedController> logger, IMachineFeed machineFeed)
    {
        _logger = logger;        _machinefeed = machineFeed;
    }

    [HttpGet("{machineid}")]
    public async Task<IActionResult> Get(string machineid, [FromQuery] PaginationFilter filter)
    {

        try
        {
            var data = _machinefeed.GetFeed(machineid, filter);

            if (data.Data == null || data.Data.Count() == 0)
            {

                string message = string.Format("No data found with ID = {0}", machineid);
                data.Message = message;


                return NotFound(data);
            }
            return Ok(data);
        }
        catch (Exception ex)
        {
            throw ex;
        }


       
    }

    
}


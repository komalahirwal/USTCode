﻿using System;

namespace Entities.FeedModels
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class Component
    {
        public Id _id { get; set; }
        public string type { get; set; }
    }

    public class ComponentId
    {
        public string oid { get; set; }
    }

    public class CreatedAt
    {
        public DateTime date { get; set; }
    }

    public class FixAreaDetails
    {
        public string areaType { get; set; }
        public List<Component> components { get; set; }
    }

    public class Id
    {
        public string oid { get; set; }
    }

    public class InitialRepairDate
    {
        public DateTime date { get; set; }
    }

    public class Machine
    {
        public Id _id { get; set; }
        public string type { get; set; }
        public string name { get; set; }
        public string imageUrl { get; set; }
    }

    public class Reason
    {
        public string type { get; set; }
    }

    public class RepairDate
    {
        public DateTime date { get; set; }
    }

    public class Repairdatum
    {
        public Id _id { get; set; }
        public UserId userId { get; set; }
        public ComponentId componentId { get; set; }
        public string repair { get; set; }
        public string text { get; set; }
        public string summary { get; set; }
        public CreatedAt created_at { get; set; }
        public UpdatedAt updated_at { get; set; }
        public RepairDate repair_date { get; set; }
        public InitialRepairDate initial_repair_date { get; set; }
        public RepairWorkflowStatus repairWorkflowStatus { get; set; }
        public Machine machine { get; set; }
        public Reason reason { get; set; }
        public User user { get; set; }
        public string reviewStatus { get; set; }
        public string workorderId { get; set; }
        public FixAreaDetails fixAreaDetails { get; set; }
    }

    public class RepairWorkflowStatus
    {
        public string initialRepairStatus { get; set; }
        public string repairStatus { get; set; }
    }

    public class Repair
    {
        public List<Repairdatum> Repairdata { get; set; }
    }

    public class UpdatedAt
    {
        public DateTime date { get; set; }
    }

    public class User
    {
        public Id _id { get; set; }
        public string name { get; set; }
    }

    public class UserId
    {
        public string oid { get; set; }
    }


}


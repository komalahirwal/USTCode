﻿using System;
namespace Entities.FeedModels
{
	public class Session
	{
		public Session()
		{

        }
        public IList<SessionsData> sessionsData { get; set; }

    }

    public class Versions
    {
        public string hwVersion { get; set; }
        public string swVersion { get; set; }

    }
    public class EndpointInfo
    {
        public string type { get; set; }
        public int installationPlane { get; set; }
        public Versions versions { get; set; }

    }
    public class Bearings
    {
        public IList<string> samples { get; set; }
        public EndpointInfo endpointInfo { get; set; }

    }
    public class Components
    {
        public string _id { get; set; }
        public string type { get; set; }
        public IList<Bearings> bearings { get; set; }

    }
    public class SessionsData
    {
        public string _id { get; set; }
        public string userId { get; set; }
        public string machineId { get; set; }
        public IList<Components> components { get; set; }
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }
        public bool continuous { get; set; }
        public string status { get; set; }
        public DateTime status_updated_at { get; set; }
        public bool enableInterim { get; set; }
        public IList<string> tags { get; set; }

    }
    


}
		


﻿using System;
namespace Entities.FeedModels
{
	public class FeedData
	{
		public FeedData()
		{
		}
		public string feedId { get; set; }
		public string machineId { get; set; }
		public DateTime createddate { get; set; }
        public DateTime updateddate { get; set; }
		public string Feedtype { get; set; }
		public int sequence { get; set; }
	}
}


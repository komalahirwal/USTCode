﻿using System;
namespace Data
{
	public class Feed
	{
		public Feed()
		{
		}

		
	}
}

